(function(){
	function init() {
		document.querySelector("body p").innerHTML = "SET data using sample.js"
	}
	document.addEventListener("DOMLoaded",init);
})();